export const AUTH_COOKIE = import.meta.env.VITE_AUTH_COOKIE;
export const LOCAL_USER = "chat-user";
